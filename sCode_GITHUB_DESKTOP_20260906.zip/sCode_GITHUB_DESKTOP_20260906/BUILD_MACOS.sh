#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64) SEED="$ROOT/bootstrap/macos-arm64/scode0"; TAG=macos-arm64 ;;
  x86_64) SEED="$ROOT/bootstrap/macos-x86_64/scode0"; TAG=macos-x86_64 ;;
  *) echo "Unsupported macOS architecture: $ARCH" >&2; exit 2 ;;
esac
[ -x "$SEED" ] || { echo "Native macOS stage-0 seed is not bundled yet: $SEED" >&2; echo "Place a verified native seed there, then rerun this script." >&2; exit 3; }
OUT="$ROOT/dist/sCode-$TAG"; rm -rf "$OUT"; mkdir -p "$OUT/bin" "$OUT/lib/sCode" "$OUT/share/sCode"
cp "$SEED" "$OUT/bin/scode"; chmod +x "$OUT/bin/scode"
cp -a "$ROOT/scode" "$OUT/lib/sCode/"; cp -a "$ROOT/apps" "$ROOT/examples" "$ROOT/docs" "$ROOT/tests" "$OUT/share/sCode/"
echo "Built $OUT"
