#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
"$ROOT/BUILD_LINUX.sh"
ARCH="$(uname -m)"; case "$ARCH" in x86_64|amd64) TAG=linux-x86_64;; aarch64|arm64) TAG=linux-arm64;; esac
SRC="$ROOT/dist/sCode-$TAG"
PREFIX="${PREFIX:-/usr/local}"
DEST="$PREFIX/lib/sCode"
mkdir -p "$DEST" "$PREFIX/bin"
cp -a "$SRC/lib/sCode/." "$DEST/"
cp -a "$SRC/share/sCode" "$DEST/share"
install -m 0755 "$SRC/bin/scode" "$PREFIX/bin/scode"
install -m 0755 "$SRC/bin/sgroovebox" "$PREFIX/bin/sgroovebox"
echo "Installed sCode to $PREFIX. Try: scode run $DEST/share/examples/hello.sC"
