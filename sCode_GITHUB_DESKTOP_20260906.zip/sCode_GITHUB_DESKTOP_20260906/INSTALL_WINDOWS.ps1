$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $Root 'BUILD_WINDOWS.ps1')
$Arch=[System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
$Tag = if ($Arch -eq 'Arm64') {'windows-arm64'} else {'windows-x86_64'}
$Src=Join-Path $Root "dist/sCode-$Tag"
$Prefix = if ($env:SCODE_PREFIX) {$env:SCODE_PREFIX} else {Join-Path $env:LOCALAPPDATA 'sCode'}
New-Item -ItemType Directory -Force -Path $Prefix,(Join-Path $Prefix 'bin') | Out-Null
Copy-Item -Recurse -Force (Join-Path $Src '*') $Prefix
Write-Host "Installed sCode to $Prefix"
Write-Host "Add $(Join-Path $Prefix 'bin') to PATH to use scode.exe globally."
