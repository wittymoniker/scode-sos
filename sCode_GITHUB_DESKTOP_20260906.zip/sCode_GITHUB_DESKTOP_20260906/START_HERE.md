# sCode Desktop GitHub Package

This is the standalone sCode source/runtime package.

## Linux x86-64 quick start
```bash
chmod +x bootstrap/linux-x86_64/scode0
./bootstrap/linux-x86_64/scode0 run examples/hello.sC
```

## Build/install entry points
- Linux: `./BUILD_LINUX.sh`, `sudo ./INSTALL_LINUX.sh`
- macOS: `./BUILD_MACOS.sh`, `./INSTALL_MACOS.sh`
- Windows PowerShell: `./BUILD_WINDOWS.ps1`, `./INSTALL_WINDOWS.ps1`

The current package includes a tested Linux x86-64 stage-0 seed. macOS and Windows scripts expect a native `scode0` seed in the matching `bootstrap/<platform>/` directory and stop with a clear message if it is absent. They do not pretend the Linux seed is portable.
