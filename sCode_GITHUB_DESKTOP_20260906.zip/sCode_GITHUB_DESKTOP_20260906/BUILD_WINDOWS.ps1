$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Arch = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
if ($Arch -eq 'X64') { $Tag='windows-x86_64'; $Seed=Join-Path $Root 'bootstrap/windows-x86_64/scode0.exe' }
elseif ($Arch -eq 'Arm64') { $Tag='windows-arm64'; $Seed=Join-Path $Root 'bootstrap/windows-arm64/scode0.exe' }
else { throw "Unsupported Windows architecture: $Arch" }
if (-not (Test-Path $Seed)) { throw "Native Windows stage-0 seed is not bundled yet: $Seed`nPlace a verified native seed there, then rerun." }
$Out=Join-Path $Root "dist/sCode-$Tag"
Remove-Item -Recurse -Force $Out -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path (Join-Path $Out 'bin'),(Join-Path $Out 'lib/sCode'),(Join-Path $Out 'share/sCode') | Out-Null
Copy-Item $Seed (Join-Path $Out 'bin/scode.exe')
Copy-Item -Recurse (Join-Path $Root 'scode') (Join-Path $Out 'lib/sCode/')
Copy-Item -Recurse (Join-Path $Root 'apps'),(Join-Path $Root 'examples'),(Join-Path $Root 'docs'),(Join-Path $Root 'tests') (Join-Path $Out 'share/sCode/')
Write-Host "Built $Out"
