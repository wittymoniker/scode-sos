#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCH="$(uname -m)"
case "$ARCH" in
  x86_64|amd64) SEED="$ROOT/bootstrap/linux-x86_64/scode0"; TAG=linux-x86_64 ;;
  aarch64|arm64) SEED="$ROOT/bootstrap/linux-arm64/scode0"; TAG=linux-arm64 ;;
  *) echo "Unsupported Linux architecture: $ARCH" >&2; exit 2 ;;
esac
[ -x "$SEED" ] || { echo "Missing native stage-0 seed: $SEED" >&2; exit 3; }
OUT="$ROOT/dist/sCode-$TAG"
rm -rf "$OUT"; mkdir -p "$OUT/bin" "$OUT/lib/sCode" "$OUT/share/sCode"
cp "$SEED" "$OUT/bin/scode"
cp -a "$ROOT/scode" "$OUT/lib/sCode/"
cp -a "$ROOT/apps" "$ROOT/examples" "$ROOT/docs" "$ROOT/tests" "$OUT/share/sCode/"
cat > "$OUT/bin/sgroovebox" <<'SH'
#!/usr/bin/env sh
SELF=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$SELF/.." && pwd)
exec "$SELF/scode" run "$ROOT/share/sCode/apps/groovebox/groovebox_native_full.sC" "$@"
SH
chmod +x "$OUT/bin/scode" "$OUT/bin/sgroovebox"
printf 'Built %s\n' "$OUT"
"$OUT/bin/scode" run "$ROOT/examples/hello.sC"
