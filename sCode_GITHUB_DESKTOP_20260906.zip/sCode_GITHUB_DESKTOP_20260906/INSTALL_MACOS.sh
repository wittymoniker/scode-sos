#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
"$ROOT/BUILD_MACOS.sh"
ARCH="$(uname -m)"; [ "$ARCH" = arm64 ] && TAG=macos-arm64 || TAG=macos-x86_64
SRC="$ROOT/dist/sCode-$TAG"
PREFIX="${PREFIX:-$HOME/.local}"
mkdir -p "$PREFIX/bin" "$PREFIX/lib/sCode"
cp -a "$SRC/lib/sCode/." "$PREFIX/lib/sCode/"
cp -a "$SRC/share/sCode" "$PREFIX/lib/sCode/share"
install -m 0755 "$SRC/bin/scode" "$PREFIX/bin/scode"
echo "Installed. Add $PREFIX/bin to PATH if needed."
