# Precomputed Stable Mode

This release is designed so first boot does **not** perform a global self-recalculation.

At build/release time sOS carries precomputed:
- file SHA-256 manifest;
- subsystem/profile registry snapshot;
- package-role map;
- native-transfer/compatibility policy metadata;
- Meum/Finite-Infinity routing metadata where available.

Runtime defaults are intentionally conservative:
- quick delta/readiness checks only;
- no automatic source simplification;
- no automatic global recompilation;
- no automatic package add/remove;
- no deep reverse-grep convergence on boot;
- corruption repair may occur automatically only when the protected replacement passes the stored SHA-256 identity.

Use `sos-deep-maintenance` when you explicitly want the expensive maintenance path.
