# sOS Gaming Layer
The gaming layer is deliberately outside the Math-First process ABI. Vulkan/OpenGL, Mesa, SDL, PipeWire, Wine, DXVK/VKD3D-Proton and Gamescope-style components can be installed or built without changing sCode bytecode/container formats.

Advanced FPS compatibility depends on GPU drivers, Vulkan support, game anti-cheat policy, Wine/Proton compatibility and the game's own requirements. sOS cannot guarantee every title. Native Linux games use the normal graphics/input/audio stack; Windows games can use Wine/Proton-class compatibility where permitted.
