#!/usr/bin/env bash
set -euo pipefail
# Host distro integration helper. Does not alter sOS Math-First core execution ABI.
if command -v dnf >/dev/null; then
 sudo dnf install -y mesa-dri-drivers mesa-vulkan-drivers vulkan-loader vulkan-tools SDL2 pipewire wireplumber gamemode wine winetricks steam-devices || true
 echo 'For Steam/Proton use your distribution/Flathub Steam package; proprietary game clients remain external.'
elif command -v apt-get >/dev/null; then
 sudo apt-get update; sudo apt-get install -y mesa-vulkan-drivers vulkan-tools libsdl2-2.0-0 pipewire wireplumber gamemode wine64 winetricks || true
else
 echo 'Unsupported package manager. Use third_party/manifests/source-stack.json or install Vulkan/Mesa/SDL/PipeWire/Wine manually.'
fi
