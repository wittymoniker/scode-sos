#!/usr/bin/env sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
scode0=$($root/scripts/find-scode0.sh)
if [ ! -x "$scode0" ]; then echo "No executable stage-0 seed for this platform: $scode0" >&2; exit 2; fi
export SCODE_PATH="$root/scode/libs${SCODE_PATH:+:$SCODE_PATH}"
exec "$scode0" run "$root/apps/groovebox/groovebox_native_full.sC" "$@"
