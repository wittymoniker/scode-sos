# spack

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run spack.sC
```

## Mathematics

Packaging is byte-preserving; package source programs retain Math-First semantics and compiler indexes when built.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
