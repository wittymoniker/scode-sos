# sOS Structural Homeostasis

sOS treats “complete” as a profile-relative dependency/capability property, not a target byte count.

The optimizer measures:

1. required subsystem completeness,
2. dependency closure,
3. preference for sCode/math-native infrastructure where a real native implementation exists,
4. integrity/protection status,
5. redundancy,
6. installed footprint versus a soft ideal and hard maximum.

The default installed-root guardrails are intentionally generous:

| Profile | Soft ideal | Hard maximum |
|---|---:|---:|
| Minimal | 2 GiB | 4 GiB |
| Desktop | 8 GiB | 12 GiB |
| Creator | 16 GiB | 24 GiB |
| Game-Ready | 28 GiB | 40 GiB |

These are not quotas. sOS never adds filler to reach the ideal. A smaller dependency-complete structure is better. The hard maximum simply prevents uncontrolled extension.

`sos-structure audit game-ready` is non-mutating and may run routinely. `sos-structure apply game-ready` requires the exact approval phrase `CONVERGE-SOS-STRUCTURE` before installing anything. It does not automatically remove arbitrary packages; removal/simplification plans remain reviewable because user data and opaque third-party dependencies can make “unused” detection unsafe.

The reported Meum score and Finite-Infinity route are project-defined diagnostics for deterministic routing/indexing. They do not establish a mathematical proof that a particular operating-system image is globally optimal.
