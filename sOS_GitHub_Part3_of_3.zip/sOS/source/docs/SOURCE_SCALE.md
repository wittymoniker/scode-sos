# Source scale

The checked-in sOS code is intentionally not padded to a target byte count. `scripts/source-sync.py` can populate `third_party/src/` from `third_party/manifests/source-stack.json`. Kernel, Mesa, LLVM, Wine, FFmpeg and related checkouts naturally move a full developer workspace into the hundreds of MB or several GB depending on clone depth/history.

This is a more meaningful "full-fledged OS source" than storing arbitrary filler. GitHub source releases can exclude `third_party/src` for compact distribution or include a shallow source cache if repository/release limits permit.
