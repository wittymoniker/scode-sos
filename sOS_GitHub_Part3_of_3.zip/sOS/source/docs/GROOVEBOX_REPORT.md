# Mathematician's Groovebox — Native sCode Project Report

## Scope

The GitHub source release contains a native sCode Groovebox execution path. It renders deterministic 48 kHz PCM WAV output and exposes an interactive shell. This report does **not** claim feature-for-feature parity with the historical ~42k-line PyQt application; the native graphical/editor/video/game migration remains a larger body of work.

## Mathematics used by the native path

The renderer currently uses:

- `MEUM` as a frequency/identity constant;
- direct-series `isn/ics` through the native sCode runtime;
- derived `isx/isy` primitives;
- `PHI` as an additional deterministic frequency relation;
- chord weights `0.3333333`, `0.1975807343`, `0.05479`;
- finite-infinity source identities through the sCode compiler when Groovebox is compiled to `.sbin`.

The complete theorem/status register is `docs/MATHEMATICS_AND_THEOREMS.md`.

## Audio path

`audio.write_groove_wav()` is implemented in the native runtime. It derives three deterministic voices, combines them with the recorded weights, and writes PCM WAV. The native path avoids a Python runtime.

## Visual/game/canonical migration

The source distribution contains `sGraph`, `sMedia`, and `sGameLab` as native sCode capability surfaces and keeps the mathematical contracts needed for continued migration. It does not claim that every historical PyQt visualizer, game window, editor, sample workflow, canonical writer, radio UI, or automation surface has already been reproduced natively.

## Determinism claim

The build can be tested for deterministic source identities and repeated native render behavior. “Claimed exact” refers only to the documented implementation contract; it is not a proof of a new universal number-theory theorem.
