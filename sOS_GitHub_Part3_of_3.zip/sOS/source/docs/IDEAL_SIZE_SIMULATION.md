# Ideal sOS structure simulation

This is an engineering sizing model, not a claim that every distro build will occupy exactly this many bytes.

For the Game-Ready profile, the current structural model allocates approximately:

- 2.5 GiB base OS
- 2.0 GiB firmware/drivers
- 2.0 GiB network/desktop/input/session
- 1.0 GiB sCode/math-native layer
- 3.0 GiB creator/media/Groovebox support
- 3.0 GiB native gaming runtime
- 5.0 GiB compatibility runtimes
- 2.0 GiB toolchain/recovery
- 2.5 GiB update/package headroom
- 5.0 GiB structural reserve

Total modeled envelope: **28 GiB**.

The optimizer treats 28 GiB as a *soft envelope*, not a target to fill. If the complete dependency/capability graph occupies 18 GiB, 18 GiB is preferred. If hardware support legitimately needs 30 GiB, the structure may exceed 28 GiB while remaining below the default 40 GiB hard ceiling. The goal is therefore minimum valid structure subject to capability, integrity, performance, and reserve constraints.

The system must not remove user data or arbitrary user-installed applications merely to meet the soft envelope. Automatic pruning is limited to packages recorded as sOS-managed and no longer required by the selected profile; all mutating convergence still requires approval.
