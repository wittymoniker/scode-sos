# Math transition compatibility

sOS separates **process/file ABI compatibility** from the selected mathematics implementation. Existing `.sC` / native `.sbin` containers remain the execution format while math calls can run in three modes:

- `legacy`: preserve old host formulas where possible.
- `compat`: default; old semantic calls route through Math ABI 2 adapters, keeping standard sin/cos equivalence through `isn(2x)/2` and `ics(2x)/2` while exposing Meum, OT, EQR and Finite Infinity explicitly.
- `native`: Math-First APIs are preferred and old source is expected to migrate.

`compat/math-transition.sh` changes the user mode and `compat/math_transition.py` audits Python/sCode/C/C++/Julia source without silently rewriting it. The C ABI in `libs/mathbridge` provides a stable boundary for hosted applications and third-party modules.

Project-defined mathematics is documented separately and should not be represented as externally established theorem unless independently proved.
