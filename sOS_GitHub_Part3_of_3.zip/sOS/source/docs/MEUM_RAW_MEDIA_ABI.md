# sCode Meum/Raw Media ABI

The native sCode media path intentionally accepts only raw/uncompressed media or MeumPack segment manifests. It does not require FFmpeg.

Accepted native forms: PCM WAV, headerless PCM (`.pcm/.raw/.sraw` with optional `.meta`), PPM frames, MIDI, `.mseq` PPM sequences, and `MEUMPACK1/2` manifests.

MeumPack is the project-defined segment/reuse representation: 64 KiB content-addressed chunks, SHA-256 authoritative integrity, Finite-Infinity route IDs and Meum expansion identity. It is not claimed to be a universal entropy codec.

`smeum-media play` uses the OS raw backends (`pw-play`/`aplay`, `aplaymidi`, and `chafa`/simple image viewers). Top-level compatibility software may use other codec stacks, but those are outside the sCode-native media ABI.
