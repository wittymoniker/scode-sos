# Native dependency policy

The authoritative sOS/sCode path is now **portable C + sCode**.

Required to build the native core:
- a C11 compiler
- libc / platform C runtime
- libm where the platform separates it
- optional `ar` for a static MathBridge archive

Not required by the installed native core:
- Python
- Julia
- a C++ compiler or C++ runtime

The historical Python/Qt/Julia/C++ Groovebox implementation is retained only under `compat/legacy-reference/` as a migration/parity reference. It is not installed by the native profiles and is excluded from the authoritative build.

Third-party gaming/workstation projects fetched into `third_party/src/` may have their own toolchain requirements. Those requirements belong to those upstream projects and are not a dependency of the sOS/sCode core.
