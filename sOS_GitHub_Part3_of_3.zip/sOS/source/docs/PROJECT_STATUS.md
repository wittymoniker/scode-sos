# Project Status

This source distribution is an experimental sOS/sCode platform built around a native sCode runtime, native package tooling, sAssistant, a native Math-First Groovebox path, and composable capability applications.

## Native projects

- **sCode** — native compiler/runtime; `.sC` source and `.sbin` artifacts; Math-First primitives; finite-infinity compiler index.
- **sApp / sPack** — native package installation and construction tools.
- **sAssistant** — native sCode conversational/system shell.
- **Groovebox** — native sCode Math-First renderer and shell. Historical PyQt feature parity is not yet claimed.
- **sMath** — Meum/OT/isn/ics/finite-infinity workbench.
- **sStudio** — sCode build/check/index workbench.
- **sWhy** — provenance/explanation surface.
- **sTrace** — process/source-index/text inspection.
- **sFiles** — native file operations shell.
- **sBuilder** — native build/rootfs/initramfs orchestration shell.
- **sInspect** — file, grep, finite-hash, and compiled-index inspection.
- **sGraph** — deterministic capability graph generation.
- **sMedia** — Math-First WAV generation utility.
- **sGameLab** — deterministic seed/world-mechanic workbench.

All project reports inherit the mathematical register in `MATHEMATICS_AND_THEOREMS.md`.
