# sAssistant

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sAssistant.native.sC
```

## Mathematics

Finite-infinity source identity for compiled assistant code; exposes explanations of the shared Meum/OT/isn/EQR register.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
