# swhy

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run swhy.sC
```

## Mathematics

Reports project-defined versus standard mathematics and explains finite-infinity compiler behavior.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
