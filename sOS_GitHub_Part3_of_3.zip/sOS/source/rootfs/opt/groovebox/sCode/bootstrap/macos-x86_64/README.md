# Stage-0 slot: macos-x86_64

No executable is fabricated in this release. Place a verified platform-specific sCode stage-0 seed here, then follow ../../START_HERE.md.
