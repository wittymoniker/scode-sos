# Linux x86-64 stage-0

`scode0` is the executable seed carried from the current native sCode lineage. It exists only to start the self-hosting chain; `.sC` files are the authoritative editable implementation target.
