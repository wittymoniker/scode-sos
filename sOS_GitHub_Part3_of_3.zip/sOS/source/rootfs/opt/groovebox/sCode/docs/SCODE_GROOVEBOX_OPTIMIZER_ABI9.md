# sCode Groovebox Optimizer ABI 9

ABI 9 is the frozen optimizer/runtime contract for the matching Groovebox+sOS appliance.
It supersedes ABI 6/7 for host integration while retaining their deterministic finite
identity, dependency, scheduling and pool semantics.

## Runtime contracts

- optimizer ABI: 8
- universal pool ABI: 3
- pool format ABI: 1
- pool formats: 18
- scheduler ABI: 2
- completion ABI: 1
- completion policies: PURE, GENERATION, FRAME, STREAM, SIDE_EFFECT
- symbol ABI: 3

All poolable requests use one identity -> affinity/lane -> generation -> buffer slot ->
coalescing -> result slot -> reuse/publication pipeline. Specialized helpers are
compatibility wrappers around the universal pool contract.

## Completion and threading

The sCode contract separates request planning from result publication. The host bridge
implements worker execution and a dedicated completion thread. PURE requests may be
reused indefinitely by identity; GENERATION and FRAME work reject stale completion;
STREAM publishes the latest-ready result; SIDE_EFFECT work is never replayed or merged
merely because an identical key exists. Qt callbacks are marshalled to the GUI thread.
The realtime audio callback performs no sCode IPC and never waits for completion locks.

## Symbol contract

The author-number scheme is `base16-squiggle-crossbar-subscale-v7`:

- values 0..15 are ordinary base-16 cells;
- 16 is the completed-cycle cell;
- every glyph has four ordered cross-bars;
- each cross-bar is absent=0, dotted=0.5 or solid=1;
- completed-cycle 16 defaults to four solid bars, solid mask 15 / dotted mask 0;
- in-cell squiggle may encode 2^-1;
- continuation fractional cells use 2^-4k weights;
- spaced fractional straight = 1/1 of its slot; unspaced = 1/2.

The full semantic face space is 17 × 2 × 2 × 3^4 = 5,188 states.

## Release gate

`scripts/test.sh` must pass using the bundled stage-0. The gate exercises every
universal pool method, every completion policy helper, compact/full symbol-plan parity,
compiler optimizer behavior, dependency/QoS policy, and native Groovebox deterministic
parity. No host-consumed optimizer field may be blank or null.


## Full-cycle 16 invariant
Cell `16` is saturated: all 12 main strokes are solid and all four ordered subdividers are solid. Dotted/missing variants of cell 16 are not valid semantic faces.
