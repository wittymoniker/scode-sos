# sCode Groovebox readiness — optimizer/runtime contract

## Cleared for Groovebox optimization

The bundled sCode stage-0 and `.sC` source provide the frozen **Groovebox Optimizer
ABI 9**. This is the required optimization/runtime contract consumed by the matching
Groovebox appliance and is covered by `scripts/test.sh`.

Cleared capabilities:
- deterministic number/logic casts and dirty masks;
- dependency propagation across Groovebox modalities;
- universal finite pooling across all 18 supported request formats;
- pool slots, generations, buffer/ring placement, result slots and reuse identities;
- scheduler lanes, coalescing, affinity, cost/budget admission and QoS cadence;
- separate completion policy for PURE, GENERATION, FRAME, STREAM and SIDE_EFFECT work;
- stale generation/frame rejection and latest-ready stream publication;
- side-effect non-reuse/non-coalescing semantics;
- bounded parallel-width selection;
- base-16/squiggle/subscale symbols with four ternary cross-bars on every glyph;
- native Groovebox deterministic parity checks;
- source-purity and method-coverage checks for the first-party sCode tree.

The Python host bridge supplies the actual worker pool, dedicated completion thread and
Qt-main-thread callback drain because the current stage-0 does not provide native host
threads/UI dispatch itself. sCode remains authoritative for the deterministic pool,
scheduler, completion and symbol policies. The realtime audio callback performs no
sCode subprocess/IPC calls.

This clears sCode as the optimizer/runtime foundation for Groovebox. It does not claim
that every long-term language goal (such as complete stage-1/stage-2 self-host closure
or every native desktop API) is finished; those are separate language/OS milestones.
