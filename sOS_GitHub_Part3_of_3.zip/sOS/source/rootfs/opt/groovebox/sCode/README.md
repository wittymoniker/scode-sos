# sCode — GitHub Source Repository

sCode is the Math-First application/runtime language used by sOS and the native Mathematician's Groovebox port.

## Architecture target

**stage-0 executable seed -> sCode compiler/runtime sources -> sCode libraries/apps**

The authoritative editable implementation in this repository is sCode (`.sC`). There are no C/C++/Python/Julia source files in this GitHub package.

`bootstrap/linux-x86_64/scode0` is an already-built bootstrap seed, not the source architecture. A blank machine needs an executable seed before a self-hosting language can rebuild itself.

## Quick start — Linux x86-64

```bash
chmod +x bootstrap/linux-x86_64/scode0
./bootstrap/linux-x86_64/scode0 run examples/hello.sC
./scripts/run-groovebox.sh
```

See `START_HERE.md` for build, test, platform and self-hosting instructions.

## Native Groovebox defaults

- Math Symbols: ON
- EQR: 0.4014
- Finite Infinity: 134964356
- Meum and Operator-Theory-compatible math libraries included

## Current boundary

The native sCode composition/export engine is operational for deterministic project/audio/frame/MIDI/world/bundle generation. The rich Qt-era desktop widget surface is still a parity target; this repository does not claim feature-for-feature GUI parity yet.

## Smart deterministic runtime

The shipped sCode library now includes `logic_math`, `runtime.pool`,
`runtime.scheduler`, and `game.runtime`. They provide explicit Boolean↔numeric
casting, finite deterministic resource routing, coalescing/scheduling identities,
and stable game entity/world/tick helpers. `sos-smart` exercises these paths on
sOS. These are engineering execution policies; optimization is retained only when
parity/correctness tests pass.
