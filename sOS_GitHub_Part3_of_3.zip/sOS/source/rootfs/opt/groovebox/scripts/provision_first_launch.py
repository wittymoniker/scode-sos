#!/usr/bin/env python3
"""Provision and verify Groovebox-local bin/ffmpeg + bin/ffprobe before first run/build."""
from __future__ import annotations
import os, platform, shutil, subprocess, sys, tarfile, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; BIN=ROOT/'bin'; BIN.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT))

def _local(name): return BIN/(name+('.exe' if os.name=='nt' else ''))
def _valid(path,name):
    if not path or not Path(path).is_file(): return False
    try:
        if os.name!='nt': Path(path).chmod(Path(path).stat().st_mode|0o111)
        r=subprocess.run([str(path),'-hide_banner','-version'],capture_output=True,text=True,timeout=10,check=False)
        return r.returncode==0 and f'{name} version' in ((r.stdout or '')+'\n'+(r.stderr or '')).lower()
    except Exception:return False

def verify(): return all(_valid(_local(n),n) for n in ('ffmpeg','ffprobe'))
def _download_linux_static():
    if platform.system().lower()!='linux': return False
    arch=platform.machine().lower()
    token='amd64' if arch in ('x86_64','amd64') else ('arm64' if arch in ('aarch64','arm64') else '')
    if not token:return False
    url=f'https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-{token}-static.tar.xz'
    arc=ROOT/'.ffmpeg-download.tar.xz'; out=ROOT/'.ffmpeg_extract'
    try:
        print('[provision] downloading static FFmpeg -> local bin/')
        urllib.request.urlretrieve(url,arc); out.mkdir(exist_ok=True)
        with tarfile.open(arc,'r:xz') as tf: tf.extractall(out)
        for name in ('ffmpeg','ffprobe'):
            src=next((p for p in out.rglob(name) if p.is_file()),None)
            if not src: return False
            shutil.copy2(src,_local(name)); _local(name).chmod(0o755)
        return verify()
    except Exception as e:
        print(f'[provision] static download unavailable: {e}',file=sys.stderr); return False
    finally:
        try: arc.unlink(missing_ok=True)
        except Exception: pass
        shutil.rmtree(out,ignore_errors=True)

def _copy_valid_host_pair():
    # Bootstrap fallback only. Runtime still resolves ONLY ./bin after this copy.
    src={n:shutil.which(n) for n in ('ffmpeg','ffprobe')}
    if not all(src.values()) or not all(_valid(src[n],n) for n in src): return False
    try:
        for n,p in src.items(): shutil.copy2(p,_local(n));
        if os.name!='nt':
            for n in src:_local(n).chmod(0o755)
        return verify()
    except Exception as e:
        print(f'[provision] host-pair copy failed: {e}',file=sys.stderr); return False

def main():
    if verify():
        print('[provision] local ffmpeg/ffprobe OK'); return 0
    # Linux static first gives the strongest self-contained result.
    if _download_linux_static() or _copy_valid_host_pair():
        print('[provision] local ffmpeg/ffprobe ready in '+str(BIN)); return 0
    print('Groovebox requires valid local bin/ffmpeg and bin/ffprobe. Provisioning failed; place a matching full FFmpeg pair in ./bin/.',file=sys.stderr)
    return 2
if __name__=='__main__': raise SystemExit(main())
