#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/native"
MODE="${1:-canonical}"
case "$MODE" in
  canonical)
    FLAGS=(-std=c++17 -O3 -DNDEBUG -flto -fPIC -fvisibility=hidden)
    ;;
  performance)
    # Still no -ffast-math. This mode enables host-CPU instruction selection.
    # It is intended for maximum local throughput, not cross-machine bit identity.
    FLAGS=(-std=c++17 -O3 -DNDEBUG -flto -fPIC -fvisibility=hidden -march=native -mtune=native)
    ;;
  *) echo "Usage: $0 [canonical|performance]" >&2; exit 2 ;;
esac
g++ "${FLAGS[@]}" -shared "$ROOT/cpp/groovebox_accel.cpp" -o "$ROOT/native/libgroovebox_accel.so"
echo "Built native/libgroovebox_accel.so ($MODE)"
