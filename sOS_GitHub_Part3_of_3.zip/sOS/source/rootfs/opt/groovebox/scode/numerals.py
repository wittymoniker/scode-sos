"""Native base-16 numeral system with configurable keyboard->glyph transliteration."""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, getcontext
from pathlib import Path
import json
getcontext().prec = 80

_ASCII = tuple('0123456789ABCDEF')

@dataclass(frozen=True)
class NumeralProfile:
    glyphs: tuple[str, ...] = _ASCII
    keys: tuple[str, ...] = tuple('0123456789abcdef')
    name: str = 'ascii-hex-compat'
    def __post_init__(self):
        if len(self.glyphs) != 16 or len(set(self.glyphs)) != 16:
            raise ValueError('sCode numeral profile requires exactly 16 unique glyphs')
        if len(self.keys) != 16 or len(set(self.keys)) != 16:
            raise ValueError('sCode keyboard profile requires exactly 16 unique keys')
    @classmethod
    def load(cls, path):
        d=json.loads(Path(path).read_text(encoding='utf-8'))
        return cls(tuple(d['glyphs']), tuple(d['keys']), d.get('name','custom-base16'))
    def save(self, path):
        Path(path).write_text(json.dumps({'name':self.name,'radix':16,'glyphs':list(self.glyphs),'keys':list(self.keys)},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    def keyboard_to_symbols(self, text: str) -> str:
        m=dict(zip(self.keys,self.glyphs)); m.update({k.upper():g for k,g in zip(self.keys,self.glyphs) if k.isalpha()})
        return ''.join(m.get(c,c) for c in text)
    def symbols_to_ascii(self, text: str) -> str:
        m={g:a for g,a in zip(self.glyphs,_ASCII)}
        # ASCII compatibility is accepted even with a custom display profile.
        for a in _ASCII: m.setdefault(a,a)
        for a in 'abcdef': m.setdefault(a,a.upper())
        return ''.join(m.get(c,c) for c in text)

DEFAULT_PROFILE=NumeralProfile()

def parse_number(token: str, profile: NumeralProfile=DEFAULT_PROFILE):
    """Parse an sCode number. Base 16 is implicit; no 0x prefix is needed."""
    t=profile.symbols_to_ascii(token.strip()).replace('_','')
    sign=-1 if t.startswith('-') else 1
    if t[:1] in '+-': t=t[1:]
    if not t: raise ValueError('empty number')
    if '.' not in t:
        return sign*int(t,16)
    whole, frac=t.split('.',1)
    whole_v=int(whole or '0',16)
    frac_v=Decimal(0); base=Decimal(16)
    for i,ch in enumerate(frac,1): frac_v += Decimal(int(ch,16))/(base**i)
    return Decimal(sign)*(Decimal(whole_v)+frac_v)

def format_number(value, profile: NumeralProfile=DEFAULT_PROFILE, fractional_digits=0):
    """Format an integer/Decimal using the profile's canonical 16 glyphs."""
    x=Decimal(str(value)); neg=x<0; x=abs(x); whole=int(x)
    digs=[]
    if whole==0: digs=['0']
    while whole: digs.append(_ASCII[whole%16]); whole//=16
    out=''.join(reversed(digs))
    if fractional_digits:
        frac=x-int(x); fd=[]
        for _ in range(int(fractional_digits)):
            frac*=16; d=int(frac); fd.append(_ASCII[d]); frac-=d
        out += '.'+''.join(fd)
    trans={a:g for a,g in zip(_ASCII,profile.glyphs)}
    out=''.join(trans.get(c,c) for c in out)
    return ('-' if neg else '')+out
