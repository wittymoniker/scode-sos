from __future__ import annotations
import json, copy
from pathlib import Path

REQUIRED_TOP = {"language_name","revision","numerals","keywords","operators","domain_words","linguistics"}

class LanguagePackError(ValueError):
    pass

def load_language_pack(path):
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    validate_language_pack(data)
    return data

def validate_language_pack(data):
    missing=REQUIRED_TOP-set(data)
    if missing:
        raise LanguagePackError(f"missing language-pack fields: {sorted(missing)}")
    nums=data["numerals"]
    if int(nums.get("base",0)) != 16:
        raise LanguagePackError("sCodeOS currently requires base 16")
    syms=list(nums.get("canonical_symbols",[]))
    if len(syms)!=16 or len(set(syms))!=16:
        raise LanguagePackError("numerals.canonical_symbols must contain exactly 16 unique symbols")
    if any(not isinstance(x,str) or not x for x in syms):
        raise LanguagePackError("every numeral symbol must be a nonempty string")
    for section in ("keywords","operators","domain_words"):
        vals=list(data.get(section,{}).values())
        if len(vals)!=len(set(vals)):
            raise LanguagePackError(f"duplicate spellings in {section}")
    return True

def teach(pack, section, concept, spelling):
    if section not in {"keywords","operators","domain_words","aliases"}:
        raise LanguagePackError(f"unsupported teach section: {section}")
    out=copy.deepcopy(pack)
    out.setdefault(section,{})[str(concept)]=str(spelling)
    validate_language_pack(out)
    return out

def teach_numeral(pack, value, glyph, keyboard_keys=None):
    value=int(value)
    if not 0 <= value < 16:
        raise LanguagePackError("numeral value must be 0..15")
    out=copy.deepcopy(pack)
    syms=list(out["numerals"]["canonical_symbols"])
    syms[value]=str(glyph)
    if len(set(syms))!=16:
        raise LanguagePackError("numeral glyphs must remain unique")
    out["numerals"]["canonical_symbols"]=syms
    for key in keyboard_keys or []:
        out["numerals"].setdefault("keyboard_map",{})[str(key)]=str(glyph)
    validate_language_pack(out)
    return out

def save_language_pack(pack, path):
    validate_language_pack(pack)
    p=Path(path)
    tmp=p.with_suffix(p.suffix+".tmp")
    tmp.write_text(json.dumps(pack,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    tmp.replace(p)
    return p
