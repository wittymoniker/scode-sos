#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SCODE="$ROOT/sCode/bootstrap/linux-x86_64/scode0"
SCRIPT="$ROOT/sCode/apps/appliance/groovebox_appliance_installer.sC"
ACTION=${1:-verify}
TARGET=${2:-0}
[ -x "$SCODE" ] || { echo "Required bundled sCode runtime missing: $SCODE" >&2; exit 3; }
[ -f "$SCRIPT" ] || { echo "sCode appliance installer missing: $SCRIPT" >&2; exit 4; }
OUT=$(cd "$ROOT/sCode" && GROOVEBOX_APPLIANCE_ACTION="$ACTION" GROOVEBOX_APPLIANCE_TARGET="$TARGET" \
  ./bootstrap/linux-x86_64/scode0 run apps/appliance/groovebox_appliance_installer.sC)
printf '%s\n' "$OUT"
printf '%s\n' "$OUT" | grep -q '^scode_appliance_abi=1$' || { echo "sCode installer ABI preflight failed" >&2; exit 5; }
case "$ACTION" in
  verify) echo "sCode appliance planning verified." ;;
  build) exec "$ROOT/BUILD_GROOVEBOX_APPLIANCE_ISO.sh" "${3:-$ROOT/dist/Groovebox-sCode-Appliance-x86_64.iso}" ;;
  burn)
    ISO=${3:-$ROOT/dist/Groovebox-sCode-Appliance-x86_64.iso}
    DEV=${4:?For burn: INSTALL_WITH_SCODE.sh burn target-id path.iso /dev/sdX}
    exec "$ROOT/BURN_GROOVEBOX_APPLIANCE_USB.sh" "$ISO" "$DEV" ;;
  *) echo "Known actions: verify, build, burn" >&2; exit 2;;
esac
