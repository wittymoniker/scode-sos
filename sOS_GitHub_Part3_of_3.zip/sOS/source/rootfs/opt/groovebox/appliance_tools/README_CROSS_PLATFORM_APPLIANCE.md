# Groovebox + required sCode standalone appliance

All platform wrappers build the same x86_64 Fedora-43/sOS appliance and stage the
complete Groovebox tree under `/opt/groovebox`. Groovebox requires the bundled
sCode optimizer at startup; there is no silent Python-only fallback in this build.

## Linux

```bash
sudo ./appliance_tools/BUILD_AND_BURN_LINUX.sh
sudo ./appliance_tools/BUILD_AND_BURN_LINUX.sh --burn /dev/sdX
```

Fedora is the primary/tested host because the appliance rootfs is configured by
DNF5. The normal builder retains the usr-merge, `/var/tmp`, `/proc`/`/sys`/`/dev`/`/run`,
and native-transfer fixes.

## macOS

Install Docker Desktop or Podman, then:

```bash
./appliance_tools/BUILD_AND_BURN_MACOS.command
./appliance_tools/BUILD_AND_BURN_MACOS.command --burn /dev/diskN
```

The build runs Fedora 43 amd64 in a privileged container. USB writing uses
`diskutil` and `dd` after verifying an external/removable whole-disk target.

## Windows

Open PowerShell. Docker Desktop or Podman Desktop is required for the Linux ISO
build. For USB writing, run PowerShell **as Administrator**.

```powershell
.\appliance_tools\BUILD_AND_BURN_WINDOWS.ps1
Get-Disk
.\appliance_tools\BUILD_AND_BURN_WINDOWS.ps1 -Burn -DiskNumber 4
```

The writer refuses boot/system disks and accepts only USB/SD/MMC bus types.

## sCode path

The bundled sCode stage-0 can verify and plan the appliance path itself:

```bash
./appliance_tools/INSTALL_WITH_SCODE.sh verify
sudo ./appliance_tools/INSTALL_WITH_SCODE.sh build
sudo ./appliance_tools/INSTALL_WITH_SCODE.sh burn 1 dist/Groovebox-sCode-Appliance-x86_64.iso /dev/sdX
```

sCode provides the deterministic identity/pool/scheduler route, while privileged
host scripts perform package-manager, ISO and raw block-device operations.

## Boot behavior

The game-ready ISO boots sOS in live mode and starts `groovebox-appliance`. That
launcher requires sCode, starts the available audio/session services, prefers
Gamescope for a fullscreen appliance session, and then launches Groovebox.
Safe/recovery mode retains the sOS console instead of auto-launching Groovebox.
