#!/usr/bin/env bash
set -u
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$KIT/.." && pwd)"
cd "$ROOT"
LOG="$KIT/linux_build_diagnostic.txt"
{
  echo '=== SYSTEM ==='; date; uname -a; cat /etc/os-release 2>/dev/null || true
  echo '=== TOOLS ==='; command -v python3; python3 --version; command -v g++ || true; g++ --version 2>/dev/null | head -1 || true; command -v ffmpeg || true
  echo '=== DISK/RAM ==='; df -h .; free -h 2>/dev/null || true
  echo '=== BUILD DOCTOR ==='; python3 "$KIT/build.py" --doctor || true
  echo '=== PYTHON IMPORTS ===';
  if [[ -x .groovebox-build-venv/bin/python ]]; then
    .groovebox-build-venv/bin/python - <<'PY'
mods=['PyQt6','numpy','sounddevice','PIL','PyInstaller']
for m in mods:
    try:
        x=__import__(m); print(m, 'OK', getattr(x,'__version__',''))
    except Exception as e: print(m, 'FAIL', repr(e))
PY
  fi
  echo '=== REQUIRED SCODE ==='
  if [[ -x sCode/bootstrap/linux-x86_64/scode0 ]]; then
    GB_OPT_ID=1 GB_OPT_DIRTY=255 GB_OPT_FRAME=0 GB_OPT_LANES=4 GB_OPT_POOL=64 GB_OPT_SHAPE=1 \
      sCode/bootstrap/linux-x86_64/scode0 run sCode/apps/groovebox/groovebox_optimizer.sC | head -30
  else
    echo 'sCode stage0 missing for this host'
  fi
} 2>&1 | tee "$LOG"
echo "Diagnostic saved to $LOG"
