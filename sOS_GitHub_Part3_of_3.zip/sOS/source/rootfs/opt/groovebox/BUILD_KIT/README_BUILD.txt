MATHEMATICIAN'S GROOVEBOX — WIN / MAC / LINUX EXECUTABLE BUILD KIT
===================================================================

This BUILD_KIT directory is designed to remain INSIDE the Groovebox project.
Every script resolves the app root as BUILD_KIT/.., so you can invoke it from
any working directory.

LINUX
  chmod +x BUILD_KIT/*.sh
  ./BUILD_KIT/install_dependencies_linux.sh
  ./BUILD_KIT/build_linux.sh --console

  When that works, make the normal GUI build:
  ./BUILD_KIT/build_linux.sh

  Output:
  dist/MathematiciansGroovebox/MathematiciansGroovebox

MACOS
  chmod +x BUILD_KIT/*.sh
  ./BUILD_KIT/install_dependencies_macos.sh
  ./BUILD_KIT/build_macos.sh --console

WINDOWS POWERSHELL
  Set-ExecutionPolicy -Scope Process Bypass
  .\BUILD_KIT\install_dependencies_windows.ps1
  .\BUILD_KIT\build_windows.ps1 -Console

WINDOWS CMD
  BUILD_KIT\build_windows.bat --console

OPTIONS
  --console     Keep terminal output visible. USE THIS FIRST so errors are visible.
  --onefile     Make one executable rather than the recommended onedir bundle.
  --no-native   Do not compile the optional C++ accelerator.
  --no-install  Reuse the existing build virtual environment without pip refresh.
  --doctor      Print environment/compiler/media-tool diagnostics only.

IMPORTANT
  Build separately on each target OS. PyInstaller does not cross-compile a
  Windows .exe from Linux or a macOS .app from Windows/Linux.

  The default is ONEDIR because Qt + SciPy + audio/native libraries are easier
  to diagnose and usually start faster. Once ONEDIR works, try --onefile.

LINUX FAILURE REPORT
  Run:
      ./BUILD_KIT/BUILD_DIAGNOSTIC.sh
      ./BUILD_KIT/build_linux.sh --console 2>&1 | tee BUILD_KIT/linux_build_error.txt

  Send back linux_build_diagnostic.txt and linux_build_error.txt. Those contain
  the useful compiler/PyInstaller errors without requiring guesswork.

FFMPEG
  System ffmpeg/ffprobe are used automatically. If you later create project
  bin/ffmpeg and bin/ffprobe, this builder also bundles those local binaries.

C++ ACCELERATOR
  The builder attempts to compile cpp/groovebox_accel.cpp and includes the
  resulting native library. If no compiler is present or compilation fails, the
  build continues using Groovebox's Python fallback so a missing C++ toolchain
  does not block creation of the application executable.
