# sCode OS target

The OS is a distribution layer, not a rewrite of the kernel. The intended first installable
image is a minimal Linux base with sCode Runtime, MatGroovebox Master Studio, native C++
acceleration, audio/video drivers and an atomic Git-tracked application release tree.

Layout:
- `/opt/scode/releases/<commit>/` immutable application releases
- `/opt/scode/current` atomic symlink to active release
- `/var/lib/scode/` user-independent state
- `$HOME/MatGroovebox/` projects/models
- rollback = repoint `current` to the last verified commit

Repository updates must build/test into a new release directory before activation. Never
`git pull` over the running studio.
