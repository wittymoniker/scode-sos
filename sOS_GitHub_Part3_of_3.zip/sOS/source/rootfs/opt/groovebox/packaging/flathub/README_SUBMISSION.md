# Flathub / KDE Discover submission checklist

This directory is a packaging scaffold, not a claim that the current repository is already accepted by Flathub.

Before submission:
1. Choose and add the project's software license. Do not submit until `project_license` in AppStream metadata matches the actual repository license.
2. Capture at least one screenshot of the actual current Linux Groovebox window and host it at a stable HTTPS URL; add it to the MetaInfo file. Concept artwork in `assets/` is branding/reference art, not a substitute for a real store screenshot.
3. Tag an immutable GitHub release and replace `REPOSITORY`, `SOURCE_TAG`, and `SOURCE_SHA256` in the manifest.
4. Make Python dependencies offline-buildable. Use Flathub's `flatpak-pip-generator` for PyPI packages (PyQt6, numpy, scipy, sounddevice, Pillow; optional integrations separately) and add its generated JSON to `modules` before the application module.
5. Bundle or build FFmpeg in the Flatpak if media import/export requires it; do not rely on the host executable from inside the sandbox.
6. Run `flatpak-builder --force-clean build-dir io.github.wittymoniker.MathematiciansGroovebox.yml` and Flathub lint before opening the submission PR.

The app uses microphone/audio output, media/project files, optional MIDI/hardware discovery, and optional network/radio features. Sandbox permissions should be kept to the minimum that each public feature actually needs.
