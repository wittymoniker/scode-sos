# sinspect

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sinspect.sC
```

## Mathematics

Directly exposes finite.hash, grep counts, and compiled finite-infinity index inspection.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
