# sfiles

Native sOS capability implemented in sCode.

## Run from source

```bash
scode run sfiles.sC
```

## Mathematics

No special numeric transform is required for ordinary file I/O; compiled source still receives finite-infinity indexing.

See `../../docs/MATHEMATICS_AND_THEOREMS.md` for definitions and theorem status.
