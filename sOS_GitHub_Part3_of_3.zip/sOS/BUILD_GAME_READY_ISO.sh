#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PROFILE=game-ready
OUT="$ROOT/dist/sOS-${PROFILE}-x86_64.iso"
NO_FETCH=0
while [ $# -gt 0 ]; do
 case "$1" in
  --profile) PROFILE=$2; shift 2;;
  --output) OUT=$2; shift 2;;
  --no-fetch) NO_FETCH=1; shift;;
  -h|--help) cat <<TXT
Usage: sudo ./BUILD_GAME_READY_ISO.sh [--profile minimal|desktop|creator|game-ready] [--output FILE.iso] [--no-fetch]

Builds a fat sOS installer. On Fedora, dependencies are installed into the ISO rootfs with dnf --installroot, then registered through the sOS native-transfer manifest/index and packed into the initramfs.
TXT
  exit 0;;
  *) echo "unknown option: $1" >&2; exit 2;;
 esac
done
case "$PROFILE" in minimal|desktop|creator|game-ready) ;; *) echo "bad profile" >&2; exit 2;; esac
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo/root so package installroot can preserve ownership." >&2; exit 3; }
for x in gzip cpio sha256sum; do command -v "$x" >/dev/null || { echo "missing: $x" >&2; exit 4; }; done
WORK="$ROOT/.fat-build/$PROFILE"
rm -rf "$WORK"; mkdir -p "$WORK/rootfs"
# Ensure a conventional rootfs skeleton exists before any package manager
# transaction. RPM scriptlets require /tmp and /var/tmp to exist and be 1777.
mkdir -p "$WORK/rootfs/tmp" "$WORK/rootfs/var/tmp" "$WORK/rootfs/var/cache" "$WORK/rootfs/var/lib" "$WORK/rootfs/var/log" "$WORK/rootfs/run"
chmod 1777 "$WORK/rootfs/tmp" "$WORK/rootfs/var/tmp"
# Seed from the current tested installer initramfs.
gzip -dc "$ROOT/dist/initramfs-sOS-scode-installer.img" | (cd "$WORK/rootfs" && cpio -idmu --quiet)
# Normalize the seed initramfs from its legacy split-/usr layout before Fedora
# filesystem packages are installed. Fedora 43 owns /bin,/sbin,/lib,/lib64 as
# usr-merge links; leaving them as real directories makes RPM unpack fail.
for pair in "bin usr/bin" "sbin usr/sbin" "lib usr/lib" "lib64 usr/lib64"; do
  set -- $pair; old=$1; new=$2
  if [ -d "$WORK/rootfs/$old" ] && [ ! -L "$WORK/rootfs/$old" ]; then
    mkdir -p "$WORK/rootfs/$new"
    cp -a "$WORK/rootfs/$old/." "$WORK/rootfs/$new/" 2>/dev/null || true
    rm -rf "$WORK/rootfs/$old"
  fi
done
# Fedora filesystem will create the canonical usr-merge links during bootstrap.

# Copy current source-side tools, then add packages.
cp -a "$ROOT/source/rootfs/." "$WORK/rootfs/"

# Install the complete sCode source/library tree and the trusted x86_64 bootstrap
# runtime into every x86_64 fat image, so sOS can check/build native modules.
mkdir -p "$WORK/rootfs/opt/sos" "$WORK/rootfs/usr/bin" "$WORK/rootfs/var/lib/sos/scode/generated/hardware"
rm -rf "$WORK/rootfs/opt/sos/sCode"
cp -a "$ROOT/source/sCode" "$WORK/rootfs/opt/sos/sCode"
if [ -x "$ROOT/source/sCode/bootstrap/linux-x86_64/scode0" ]; then
  install -m755 "$ROOT/source/sCode/bootstrap/linux-x86_64/scode0" "$WORK/rootfs/usr/bin/scode"
fi
# Final rootfs temp-dir assertion after initramfs/source overlays.
mkdir -p "$WORK/rootfs/tmp" "$WORK/rootfs/var/tmp"
chmod 1777 "$WORK/rootfs/tmp" "$WORK/rootfs/var/tmp"
ls -ld "$WORK/rootfs/tmp" "$WORK/rootfs/var/tmp"
if [ "$NO_FETCH" -eq 0 ]; then "$ROOT/scripts/fat/fetch_into_rootfs.sh" "$WORK/rootfs" "$PROFILE"; fi
# Mark profile and install the live setup tools.
printf '%s\n' "$PROFILE" > "$WORK/rootfs/etc/sos/baked-profile"
for t in sos-network-setup sos-profile-wizard sos-native-transfer sos-live-rebuild sos-structure sos-structured sos-smart sos-scode-grow sos-scode-library sos-scode-build sos-hardware sos-hardware-modality sos-health-optimize sos-ready-check sos-game-launch sos-game-ready-check; do
  [ -f "$ROOT/source/rootfs/usr/bin/$t" ] && install -m755 "$ROOT/source/rootfs/usr/bin/$t" "$WORK/rootfs/usr/bin/$t"
done
"$ROOT/scripts/fat/repack_initramfs.sh" "$WORK/rootfs" "$ROOT/iso-root/boot/initramfs.img"
cp "$ROOT/iso-root/boot/initramfs.img" "$ROOT/dist/initramfs-sOS-scode-installer.img"
# Build ISO with existing trusted wrapper.
"$ROOT/build_iso.sh" "$OUT"
echo "Fat profile: $PROFILE"
echo "ISO: $OUT"
