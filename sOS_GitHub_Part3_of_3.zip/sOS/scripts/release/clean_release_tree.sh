#!/bin/sh
set -eu
ROOT=${1:-.}
rm -rf "$ROOT/.structure-repack" "$ROOT/.fat-build" "$ROOT/.live-rebuild" "$ROOT/.qemu" "$ROOT/__pycache__"
find "$ROOT" -name '*.pyc' -delete 2>/dev/null || true
