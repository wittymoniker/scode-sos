#!/usr/bin/env bash
set -euo pipefail
ROOT=${1:?rootfs required}
PROFILE=${2:-desktop}
PKGLIST=${3:-}
DEST="$ROOT/etc/sos/native-transfer"
mkdir -p "$DEST"
M=1.1975807343385265
I=134964356
MAN="$DEST/${PROFILE}.manifest"
{
  echo "sOS-native-transfer-v1"
  echo "profile=$PROFILE"
  echo "MEUM=$M"
  echo "FINITE_INFINITY=$I"
  echo "policy=os-extension=>adapt;top-level-app=>wrap"
  [ -f "$PKGLIST" ] && sed 's/^/package=/' "$PKGLIST"
} > "$MAN"
# Hash strategic executable/library surfaces. SHA-256 is authoritative integrity;
# FI/Meum labels are deterministic routing references, not security hashes.
IDX="$DEST/${PROFILE}.index.tsv"
: > "$IDX"
for p in "$ROOT"/usr/bin "$ROOT"/usr/lib "$ROOT"/usr/lib64; do
  [ -d "$p" ] || continue
  find "$p" -type f -size -32M -print0 2>/dev/null | while IFS= read -r -d '' f; do
    rel=${f#"$ROOT"}
    sha=$(sha256sum "$f" | awk '{print $1}')
    # Stable FI route from the first 15 hex digits. Parse one nibble at a time
    # and reduce modulo I at every step. This avoids Bash integer/parser issues
    # (including escaped/locale-corrupted 0x strings) and cannot overflow.
    hex=${sha:0:15}
    h=$(awk -v x="$hex" -v mod="$I" '
      function hv(c, p) {
        p=index("0123456789abcdef", tolower(c));
        if (p==0) return -1;
        return p-1;
      }
      BEGIN {
        v=0;
        for (i=1; i<=length(x); i++) {
          d=hv(substr(x,i,1));
          if (d<0) { print 0; exit 2 }
          v=(v*16+d)%mod;
        }
        printf "%.0f\n", v;
      }')
    awk -v r="$rel" -v s="$sha" -v h="$h" -v m="$M" 'BEGIN{printf "%s\t%s\t%d\t%.12f\n",r,s,h,(h*m)%134964356}' >> "$IDX"
  done
 done
