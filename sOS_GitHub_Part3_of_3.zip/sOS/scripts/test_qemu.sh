#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ISO="${1:-$ROOT/dist/sOS-installer-x86_64.iso}"
command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo "Install qemu-system-x86"; exit 2; }
[ -f "$ISO" ] || { echo "ISO not found: $ISO"; exit 2; }
exec qemu-system-x86_64 -m 2048 -enable-kvm -cdrom "$ISO" -boot d
