# sOS Game-Ready Network Installer Kit — 2026-09-06

Start with `GAME_READY_INSTALLER.md`.

Key entry points:

- `BUILD_GAME_READY_ISO.sh --profile game-ready` — fetch/bake useful dependencies and build the ISO.
- `sos-profile-wizard` — installer profile chooser.
- `sos-network-setup` — Ethernet/Wi-Fi setup from the live environment.
- `sos-native-transfer PATH [infra|app]` — Math/sCode adaptation policy boundary.
- `sos-compat-transfer`, `sos-continuum`, `sos-meum-pack`, `sos-protect`, `sos-simplify` — continuum/reverse-grep/Meum infrastructure inherited from the previous release.

All current default sOS apps and sCode/Groovebox source remain included.

## Structural homeostasis

This release adds `sos-structure`, a profile-aware structural completeness and convergence planner. It uses dependency/capability closure as the primary objective and installed size only as a guardrail. See `source/docs/STRUCTURAL_HOMEOSTASIS.md`.

## Smart Game-Ready Fix 6

Use `sudo ./BUILD_GAME_READY_ISO.sh` for the Fedora game-ready image. The builder
now provides a normal proc/sys/dev/run environment to RPM scriptlets, robust
native-transfer indexing, sCode logic/math casting and deterministic pooling,
`gamescope`/PipeWire game-session support, and the `sos-game-ready-check` command.

For the complete smart/game-ready path, the convenience entry point is:

    sudo ./BUILD_SMART_GAME_READY_ISO.sh

It delegates to the same tested game-ready builder with the Fedora installroot,
scriptlet-mount, native-transfer, sCode smart-runtime, and ISO-output fixes enabled.
