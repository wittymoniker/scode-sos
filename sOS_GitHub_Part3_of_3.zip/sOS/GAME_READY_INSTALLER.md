# sOS Game-Ready / Network Installer

This release adds a **fat ISO builder** and an **optional network setup profile** to the continuum/Meum installer lineage.

## Fast path (Fedora build host)

```bash
sudo dnf install -y cpio gzip xorriso grub2-tools-extra
sudo ./BUILD_GAME_READY_ISO.sh --profile game-ready
```

Profiles: `minimal`, `desktop`, `creator`, `game-ready`.

The Fedora path uses `dnf --installroot` so selected packages become part of the initramfs that is actually written into the ISO. This is persistent across installs because the installer clones the rebuilt image, rather than merely installing packages into a temporary RAM session.

## Native-transfer policy

OS-level extensions (libraries, drivers, codecs, runtimes, build tools) default to sOS Math/sCode adaptation: reverse/Math grep indexing, continuum classification, compatibility registration, Meum/FI routing identity, SHA-256 integrity, and protection manifests. This is an adaptation/ABI boundary, not a claim that arbitrary third-party machine code has literally been transpiled into sCode source.

Top-level applications default to compatibility wrapping. Users can explicitly opt into deeper conversion work when source is available.

## Game-ready payload

The profile requests Mesa/Vulkan, PipeWire/WirePlumber, SDL2, GameMode, Wine/Winetricks, QEMU user emulation, FFmpeg, firmware/networking, Flatpak, diagnostics, and performance utilities where the host repositories provide them. Steam/Proton and proprietary launchers remain optional top-level applications and should be installed from the user's chosen repository/Flatpak source.

## Wi-Fi during install

The install mode runs `sos-profile-wizard`. `sos-network-setup` uses NetworkManager/nmcli when they are present in the fat image. Ethernet is used automatically when already configured.

## Current validation boundary

The scripts are syntax-checked and the installer payload structure can be validated in this package. A final ISO still requires `grub-mkrescue`/`xorriso` on the build host and must be boot-tested in QEMU and then on hardware before being called production-ready.

## Native media vs compatibility codecs
`smeum-player` is the sOS/sCode-native media path and accepts raw data or MeumPack manifests only. It uses PipeWire/ALSA for PCM and Chafa/simple image viewers for raw PPM, and does not require FFmpeg. `ffmpeg-free` in the Game-Ready package profile is retained only as a conventional compatibility dependency for third-party/top-level software that expects it; it is not part of the sCode-native media ABI.
