# Intel Mac
Uses the x86-64 kernel/userspace family but requires real EFI/Mac hardware validation. No claim of compatibility with every Intel Mac model.
