# sOS target matrix

| Target | Image format | Current status |
|---|---|---|
| PC x86-64 (AMD/Intel desktops/laptops) | installer ISO | primary exercised rootfs target; final ISO boot still requires local grub/xorriso build+test |
| PC ARM64 | disk image | scaffold; requires ARM64 kernel + stage-0 seed |
| Intel Mac | x86-64 ISO/EFI | scaffold; not hardware validated |
| Apple Silicon Mac | ARM64 image | scaffold; requires Apple-specific boot/kernel work |
| Raspberry Pi ARM64 | SD-card image | scaffold; requires board kernel/DTB/firmware |
| Orange Pi ARM64 | SD/eMMC image | scaffold; board-specific kernel/DTB/firmware required |
| Generic mobile ARM64 | device image | scaffold only; device-specific kernel/DTB/firmware/modem/power stack required |

## 32 GB x86-64 rugged/tablet deployment notes

| Target family | Image | Status |
|---|---|---|
| Dell Latitude Rugged-class Intel/AMD x86-64, 32 GB | x86-64 UEFI installer ISO | architecture compatible; live-USB peripheral validation required |
| HIGOLEPC Intel/AMD x86-64, 32 GB | x86-64 UEFI installer ISO | architecture compatible; exact touch/Wi-Fi/camera/sensor validation required |

These entries are intentionally vendor-neutral at runtime: device IDs are discovered rather than hard-coded.
