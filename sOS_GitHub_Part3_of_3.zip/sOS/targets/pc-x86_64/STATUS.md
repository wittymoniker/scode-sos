# PC x86-64
Primary current installer target for AMD/Intel desktops and laptops. The live rootfs and sCode/Groovebox execution have been exercised in the build environment. The final BIOS/UEFI ISO still must be generated with grub-mkrescue+xorriso and boot-tested on QEMU/real hardware.
