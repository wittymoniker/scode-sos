# mac-apple-silicon
This target is scaffolded but is not boot-validated. Do not build a generic image without the target-specific kernel, device tree, firmware and sCode stage-0 seed required by the hardware.
