#!/usr/bin/env bash
set -euo pipefail

ROOT=${1:?rootfs required}
PROFILE=${2:-game-ready}
HERE="$(cd "$(dirname "$0")/../.." && pwd)"
FED="$HERE/profiles/packages/${PROFILE}-fedora.txt"
DEB="$HERE/profiles/packages/${PROFILE}-debian.txt"
# RPM/DNF scriptlets expect a normal filesystem skeleton inside installroot.
# In particular RPM uses /var/tmp for temporary scriptlet files.
mkdir -p \
  "$ROOT/etc/sos" \
  "$ROOT/tmp" \
  "$ROOT/var/tmp" \
  "$ROOT/var/cache" \
  "$ROOT/var/lib" \
  "$ROOT/var/log" \
  "$ROOT/run"
chmod 1777 "$ROOT/tmp" "$ROOT/var/tmp"

echo "[sOS] rootfs temp dirs ready: $ROOT/tmp $ROOT/var/tmp"

# Give package scriptlets a normal install environment. Fedora systemd/udev and
# PipeWire/WirePlumber scriptlets inspect proc/sys/dev/run; without these mounts
# they emit warnings and may skip generated databases. Mount only for the build
# transaction and always unwind them on exit.
_MOUNTED=""
mount_one(){
  src=$1; dst=$2; mode=${3:-bind}
  mkdir -p "$dst"
  if mountpoint -q "$dst" 2>/dev/null; then return 0; fi
  if [ "$mode" = proc ]; then
    mount -t proc proc "$dst" && _MOUNTED="$dst $_MOUNTED"
  elif [ "$mode" = sys ]; then
    mount -t sysfs sysfs "$dst" && _MOUNTED="$dst $_MOUNTED"
  else
    mount --rbind "$src" "$dst" && mount --make-rslave "$dst" 2>/dev/null || true
    if mountpoint -q "$dst" 2>/dev/null; then _MOUNTED="$dst $_MOUNTED"; fi
  fi
}
cleanup_mounts(){
  for m in $_MOUNTED; do umount -R "$m" 2>/dev/null || umount -l "$m" 2>/dev/null || true; done
}
trap cleanup_mounts EXIT INT TERM
mount_one /proc "$ROOT/proc" proc
mount_one /sys "$ROOT/sys" sys
mount_one /dev "$ROOT/dev" bind
mount_one /run "$ROOT/run" bind

# Fedora 43 is usr-merged. Older/minimal seed roots may carry real /bin,/sbin,
# /lib,/lib64 directories. Move their contents under /usr and remove the real
# directories so the Fedora filesystem RPM can install its canonical links.
for pair in "bin usr/bin" "sbin usr/sbin" "lib usr/lib" "lib64 usr/lib64"; do
  set -- $pair; old=$1; new=$2
  if [[ -d "$ROOT/$old" && ! -L "$ROOT/$old" ]]; then
    mkdir -p "$ROOT/$new"
    cp -a "$ROOT/$old/." "$ROOT/$new/" 2>/dev/null || true
    rm -rf "$ROOT/$old"
    echo "[sOS] normalized legacy /$old into /$new for Fedora usr-merge"
  fi
done

filter_list(){ grep -Ev '^[[:space:]]*(#|$)' "$1"; }

if command -v dnf5 >/dev/null 2>&1 || command -v dnf >/dev/null 2>&1; then
  echo "[sOS] Fedora-family fat build: $PROFILE"
  echo "[sOS] fetch_into_rootfs revision: DNF5-HOST-CONFIG-USRMERGE-SMART-FIX6"
  mapfile -t pkgs < <(filter_list "$FED")

  if command -v dnf5 >/dev/null 2>&1; then
    RELEASEVER="${SOS_RELEASEVER:-$(rpm -E '%fedora' 2>/dev/null || true)}"
    if [[ -z "$RELEASEVER" || "$RELEASEVER" == '%fedora' ]]; then
      RELEASEVER="$(. /etc/os-release 2>/dev/null; printf '%s' "${VERSION_ID:-}")"
    fi
    [[ -n "$RELEASEVER" ]] || { echo "[sOS] ERROR: could not determine Fedora releasever" >&2; exit 6; }

    echo "[sOS] DNF5 binary: $(command -v dnf5)"
    echo "[sOS] DNF releasever: $RELEASEVER"
    echo "[sOS] Verifying HOST repositories before installroot transaction..."

    # Keep this deliberately minimal. DNF5 documents --use-host-config as the
    # switch that makes config, repo definitions and vars come from the host
    # while packages themselves are installed into --installroot.
    dnf5 --use-host-config --releasever="$RELEASEVER" repolist

    # Bootstrap Fedora's filesystem package first. It owns the standard
    # directory layout used by RPM scriptlets, including /var/tmp semantics.
    echo "[sOS] Bootstrapping Fedora filesystem package into installroot..."
    dnf5 -y \
      --installroot="$ROOT" \
      --use-host-config \
      --releasever="$RELEASEVER" \
      --setopt=install_weak_deps=False \
      install filesystem

    # Reassert temp directories *after* filesystem bootstrap and immediately
    # before the main RPM transaction.
    mkdir -p "$ROOT/tmp" "$ROOT/var/tmp"
    chmod 1777 "$ROOT/tmp" "$ROOT/var/tmp"
    [[ -d "$ROOT/var/tmp" && -w "$ROOT/var/tmp" ]] || {
      echo "[sOS] ERROR: installroot /var/tmp is missing or not writable: $ROOT/var/tmp" >&2
      ls -ld "$ROOT" "$ROOT/var" "$ROOT/var/tmp" 2>&1 || true
      exit 7
    }
    echo "[sOS] verified installroot temp dirs:"
    ls -ld "$ROOT/tmp" "$ROOT/var/tmp"

    echo "[sOS] Installing ${#pkgs[@]} requested packages into $ROOT"
    TMPDIR="$ROOT/var/tmp" dnf5 -y \
      --installroot="$ROOT" \
      --use-host-config \
      --releasever="$RELEASEVER" \
      --setopt=install_weak_deps=False \
      install "${pkgs[@]}"
  else
    RELEASEVER="${SOS_RELEASEVER:-$(rpm -E '%fedora' 2>/dev/null || true)}"
    [[ -n "$RELEASEVER" && "$RELEASEVER" != '%fedora' ]] || RELEASEVER="$(. /etc/os-release; printf '%s' "${VERSION_ID:-}")"
    echo "[sOS] legacy DNF releasever: $RELEASEVER"
    dnf -y --installroot="$ROOT" --releasever="$RELEASEVER" \
      --setopt=install_weak_deps=False install "${pkgs[@]}"
  fi

  cp "$FED" "$ROOT/etc/sos/fat-packages.txt"

  # Groovebox appliance Python realtime audio dependency. Fedora 43 carries
  # PortAudio and the other native libraries; install the small Python binding
  # into the target root and verify the complete application import surface.
  if [[ "$PROFILE" == "game-ready" && -f "$ROOT/opt/groovebox/requirements.txt" ]]; then
    echo "[sOS] Installing/verifying Groovebox Python runtime in installroot..."
    mkdir -p "$ROOT/etc"
    cp -Lf /etc/resolv.conf "$ROOT/etc/resolv.conf" 2>/dev/null || true
    chroot "$ROOT" /usr/bin/python3 -m pip install --no-cache-dir --break-system-packages sounddevice
    chroot "$ROOT" /usr/bin/python3 -c 'import numpy, PyQt6.QtCore, PIL, sounddevice; print("[sOS] Groovebox Python runtime: OK")'
    chroot "$ROOT" /bin/bash -lc 'cd /opt/groovebox/sCode && GB_OPT_ID=11 GB_OPT_DIRTY=255 GB_OPT_FRAME=0 GB_OPT_LANES=4 GB_OPT_POOL=64 GB_OPT_SHAPE=1 GB_OPT_EDITING=0 GB_OPT_LOW_POWER=0 GB_OPT_BUDGET=999 GB_OPT_DEP_READY=1 ./bootstrap/linux-x86_64/scode0 run apps/groovebox/groovebox_optimizer.sC > /tmp/groovebox-scode-plan && grep -q "^scode_optimizer_abi=9$" /tmp/groovebox-scode-plan && grep -q "^pool_abi=3$" /tmp/groovebox-scode-plan && grep -q "^scheduler_abi=2$" /tmp/groovebox-scode-plan && grep -q "^completion_abi=1$" /tmp/groovebox-scode-plan && grep -q "^completion_policy_count=5$" /tmp/groovebox-scode-plan && grep -q "^symbol_abi=4$" /tmp/groovebox-scode-plan && grep -q "^symbol_base=16$" /tmp/groovebox-scode-plan && grep -q "^symbol_full_cycle=16$" /tmp/groovebox-scode-plan && grep -q "^symbol_variant_count=5188$" /tmp/groovebox-scode-plan && grep -q "^symbol_crossbar_count=4$" /tmp/groovebox-scode-plan && grep -q "^symbol_crossbar_state_count=3$" /tmp/groovebox-scode-plan && grep -q "^symbol_full_cycle_main_strokes=12$" /tmp/groovebox-scode-plan && grep -q "^symbol_full_cycle_main_strokes_solid=12$" /tmp/groovebox-scode-plan && grep -q "^symbol_full_cycle_solid_mask=15$" /tmp/groovebox-scode-plan && grep -q "^symbol_full_cycle_dotted_mask=0$" /tmp/groovebox-scode-plan && for k in pool_slot generation audio_lane visual_lane game_lane media_lane ui_lane canonical_lane symbol_lane project_lane run_audio run_visual run_game run_media run_ui run_project run_canonical run_symbols audio_result_slot visual_result_slot game_result_slot media_result_slot ui_result_slot canonical_result_slot symbol_result_slot project_result_slot coalesce_bucket background_cadence parallel_width; do grep -Eq "^${k}=-?[0-9]+$" /tmp/groovebox-scode-plan || exit 1; done'
    echo "[sOS] Required Groovebox sCode optimizer: OK (concrete plan)"
  fi

  "$HERE/scripts/fat/native_transfer_manifest.sh" "$ROOT" "$PROFILE" "$FED"

elif command -v apt-get >/dev/null 2>&1 && command -v dpkg-deb >/dev/null 2>&1; then
  echo "[sOS] Debian-family extraction build: $PROFILE"
  WORK=$(mktemp -d); trap 'rm -rf "$WORK"' EXIT
  mapfile -t pkgs < <(filter_list "$DEB")
  (cd "$WORK" && apt-get download "${pkgs[@]}")
  for deb in "$WORK"/*.deb; do dpkg-deb -x "$deb" "$ROOT"; done
  cp "$DEB" "$ROOT/etc/sos/fat-packages.txt"
  "$HERE/scripts/fat/native_transfer_manifest.sh" "$ROOT" "$PROFILE" "$DEB"
  echo "NOTE: apt download extraction does not configure packages; Fedora installroot is the stronger tested design." > "$ROOT/etc/sos/DEBIAN_EXTRACTION_NOTE"
else
  echo "No supported host package manager. Fedora: dnf; Debian/Ubuntu: apt-get + dpkg-deb." >&2
  exit 2
fi
